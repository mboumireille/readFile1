package com.example.readFile.Service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.springframework.stereotype.Component;

import com.example.readFile.Domain.Etudiants;
import com.example.readFile.Repository.repositoryPage;

@Component
public class pageService implements repositoryPage {
	final private File filename= new File ("etudiant.txt");
	Etudiants etudiants= new Etudiants();
	
	@Override
	public String readFile() {
		// TODO Auto-generated method stub
		 String data = null;
		 try {
//		       myObj = new File(filename);
		      Scanner myReader = new Scanner(filename);
		      while (myReader.hasNextLine()) {
		        data= myReader.nextLine();
		        
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		return data;
	}

}
