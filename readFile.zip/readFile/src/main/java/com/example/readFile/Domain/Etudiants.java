package com.example.readFile.Domain;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@EntityScan

public class Etudiants {
	private String  matricule;
	private String nom;
	public Etudiants(String matricule, String nom) {
		super();
		this.matricule = matricule;
		this.nom = nom;
	}
	public Etudiants() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMatricule() {
		return matricule;
	}
	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	

}
