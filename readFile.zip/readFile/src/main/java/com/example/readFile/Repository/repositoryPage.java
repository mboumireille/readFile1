package com.example.readFile.Repository;

public interface repositoryPage {

	public String readFile();
}
