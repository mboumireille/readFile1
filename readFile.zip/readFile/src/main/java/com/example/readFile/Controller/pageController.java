package com.example.readFile.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.example.readFile.Service.pageService;

@Controller
public class pageController {


@Autowired
pageService service;
private String recuperationMatricule ;
//private String recuperationNom;

public String retourPage() {
	
	String recup= service.readFile();
	String[] words = recup.split(", ");
    for (String word : words) {
    	recuperationMatricule=word;
//    	recuperationNom=word;
    }
	return recuperationMatricule;
	
}

}
