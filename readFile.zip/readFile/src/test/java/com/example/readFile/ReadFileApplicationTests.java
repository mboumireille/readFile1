package com.example.readFile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
